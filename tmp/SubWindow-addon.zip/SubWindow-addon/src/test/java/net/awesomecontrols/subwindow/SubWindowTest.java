package net.awesomecontrols.subwindow;

import junit.framework.Assert;
import org.junit.Test;

// JUnit tests here
public class SubWindowTest {

	@Test
	public void thisAlwaysPasses() {
		Assert.assertEquals(true, true);
	}
}
